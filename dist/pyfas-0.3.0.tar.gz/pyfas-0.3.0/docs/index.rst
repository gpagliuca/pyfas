.. Pyfas documentation master file, created by
   sphinx-quickstart on Tue Jan 24 11:31:38 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Pyfas's documentation!
=================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:
   :numbered:

   ./notebooks/Introduction.ipynb
   ./notebooks/OLGA_tpl
   ./notebooks/OLGA_ppl
   ./notebooks/Unisim_usc.ipynb
   ./notebooks/Tab_files.ipynb
   ./notebooks/GAP_interface.ipynb
   ./notebooks/SFC_interface.ipynb
   ./notebooks/utilities.ipynb


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
